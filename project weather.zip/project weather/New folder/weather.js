let city = document.querySelector('#city');
let button=document.querySelector('#button');
console.log(city);

console.log("weather API"); 
let avdheshkey2 :"6bfa4a784fa2fd0c7adfa5ac08c2fe7c" ;
//let avdheshkey1 ="6798a0c822051e56fedbc5f56f237e6b";
let weather= { avdheshkey2 :"6bfa4a784fa2fd0c7adfa5ac08c2fe7c",
fetchWeather:function(city)
{
    fetch("https://api.openweathermap.org/data/2.5/weather?q="+city+"&appid="+this.avdheshkey2)
    .then(res =>res.json())
    .then(data => this.displayweather(data));
},
displayweather: function(data){
    const {name }= data;
    const {temp} = data.main;
    const {description} =data.weather[0];
    const{humidity} =data.main;
    const{wind} = data.wind;
    console.log(name,temp,description,humidity,wind);
    document.querySelector(".city").innerHTML= name;
},
    inputfield:function(){
        this.fetchWeather(document.querySelector("#city").value);
    },

};


// button.addEventListener('click',function(){
//     fetch('https://api.openweathermap.org/data/2.5/weather?q="+city+"&appid='+avdheshkey1)
//     .then(res =>res.json())
//     .then(data => document.getElementById('mydiv').innerHTML=
//         ('city is: '+data['name']+' <br> maximum temperature'
//     +data['main']['temp_max']+'<br> wind speed: '+data['']
//      ))

// }); 



//let avdheshkey2 ="6bfa4a784fa2fd0c7adfa5ac08c2fe7c";
//.catch(console.log("failure"))
//.then(data => console.log('city is: '+data['name']+'maximum temperature'+data['main']['temp_max']))
//let avdhesh ='6bfa4a784fa2fd0c7adfa5ac08c2fe7c'


//https://openweathermap.org/api  .....weather map waali website